MedPal is a personal medical tracker that lets users manage their well-being online by helping them record and monitor their health particulars.
The vision behind MedPal is to empower everyone with full control over their medical data.
